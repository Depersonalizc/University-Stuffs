def least_int(m):
    
    m = int(m)                          # converts m into int to avoid possible float-int comparison
    n = 0                               # initializes n

    while n**2 <= m:                    # iterates until n^2 > m
        n += 1                          # each time adding 1 to n

    return n
            





while True:


    try:
        user_num = float(input('Enter a number: '))    # prompts user for input (possibly float)

    

    except:
        print('Invalid input. Please enter again.')



    else:
        m = int(user_num)                   # converts float into int to avoid float-int comparison
        
        print(
            least_int(m)
        )