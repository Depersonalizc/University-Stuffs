def display_digits():

    try:

        num = int(input('Enter an integer: '))          # prompts user for input


    except:

        print(
        'Invalid input. Please enter again.'
        )
    
    
    else:

        for dgt in str(num):                        # interates thru digits of number and display
            print(dgt)





while True:
    display_digits()