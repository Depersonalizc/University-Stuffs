def initial_deposit(final, rate, years):
    
    init = final / (1 + rate / 100) ** years
    
    return init

def calculate_doposit():
    

    try:

        final_account_value = float(input('Enter the final account value: '))
        annual_interest_rate = float(input('Enter the annual interest rate: '))     # prompts user for input
        number_of_years = float(input('Enter the number of years: '))
        


    except:

        print(
            'Invalid input. Please enter again.'
        )



    else:

        init = initial_deposit(final_account_value, annual_interest_rate, number_of_years)
        
        print(
            'The initial value is: {}'.format(init)      # displays the initial deposit
        )





while True:
    calculate_doposit()